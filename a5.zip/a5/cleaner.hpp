#include "utils.hpp"
#define PROPORTIONALITY 1

void cleaner(int id);