#include "utils.hpp"

void guest(int id, int priority);